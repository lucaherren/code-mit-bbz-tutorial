var spieler = document.querySelector(".player");

var spielfeld = document.querySelector(".playground");
var vollbildButton = document.querySelector(".fullscreen");

var spielfeld = document.querySelector(".playground");
var backgroundPosition = 0;

vollbildButton.addEventListener("click", function () {
  spielfeld.requestFullscreen();
});

spieler.style.left = "0px";
spieler.style.bottom = "50px";

function loop() {
  if (keyboard(32) && parseInt(spieler.style.bottom) == 50) {
    spieler.style.bottom = parseInt(spieler.style.bottom) + 80 + "px";
  }
  if (parseInt(spieler.style.bottom) < 20 && timerspielerfallen.ready()) {
    spieler.style.bottom = parseInt(spieler.style.bottom) - 80 + "px";
  }
  if (keyboard(39)) {
    spieler.style.left = parseInt(spieler.style.left) + 5 + "px";
  }
  if (keyboard(37)) {
    spieler.style.left = parseInt(spieler.style.left) - 5 + "px";
  }

  backgroundPosition = backgroundPosition + 1;
  spielfeld.style.backgroundPosition = `-${backgroundPosition}px 0`;
  window.requestAnimationFrame(loop);
}

window.requestAnimationFrame(loop);
